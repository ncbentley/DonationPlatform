const { DynamoDB } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocument } = require('@aws-sdk/lib-dynamodb');
const Web3 = require('web3');

// Contract ABI (copy the relevant parts from your contract ABI)
const contractABI = [
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": true,
                "internalType": "address",
                "name": "user",
                "type": "address"
            },
            {
                "indexed": false,
                "internalType": "uint256",
                "name": "amount",
                "type": "uint256"
            },
            {
                "indexed": false,
                "internalType": "uint256",
                "name": "duration",
                "type": "uint256"
            }
        ],
        "name": "DonationMade",
        "type": "event"
    },
    {
        "anonymous": false,
        "inputs": [
            {
                "indexed": true,
                "internalType": "address",
                "name": "referrer",
                "type": "address"
            }
        ],
        "name": "ReferrerActivated",
        "type": "event"
    },
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "",
                "type": "address"
            }
        ],
        "name": "users",
        "outputs": [
            {
                "internalType": "address",
                "name": "sponsor",
                "type": "address"
            },
            {
                "components": [
                    {
                        "internalType": "uint256",
                        "name": "amount",
                        "type": "uint256"
                    },
                    {
                        "internalType": "uint256",
                        "name": "startTime",
                        "type": "uint256"
                    },
                    {
                        "internalType": "uint256",
                        "name": "duration",
                        "type": "uint256"
                    },
                    {
                        "internalType": "uint256",
                        "name": "totalWithdrawn",
                        "type": "uint256"
                    },
                    {
                        "internalType": "uint256",
                        "name": "lastPayoutTime",
                        "type": "uint256"
                    },
                    {
                        "internalType": "uint256",
                        "name": "payoutsClaimed",
                        "type": "uint256"
                    }
                ],
                "internalType": "struct DonationPlatform.Donation",
                "name": "donation",
                "type": "tuple"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [],
        "name": "getUserDetails",
        "outputs": [
            {
                "internalType": "uint256",
                "name": "amount",
                "type": "uint256"
            },
            {
                "internalType": "uint256",
                "name": "duration",
                "type": "uint256"
            },
            {
                "internalType": "uint256",
                "name": "startTime",
                "type": "uint256"
            },
            {
                "internalType": "uint256",
                "name": "lastPayoutTime",
                "type": "uint256"
            },
            {
                "internalType": "uint256",
                "name": "payoutsClaimed",
                "type": "uint256"
            },
            {
                "internalType": "uint256",
                "name": "totalWithdrawn",
                "type": "uint256"
            },
            {
                "internalType": "bool",
                "name": "isReferrer",
                "type": "bool"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    },
    {
        "inputs": [
            {
                "internalType": "address",
                "name": "",
                "type": "address"
            }
        ],
        "name": "referrers",
        "outputs": [
            {
                "internalType": "bool",
                "name": "isActive",
                "type": "bool"
            },
            {
                "internalType": "uint256",
                "name": "commissionEarned",
                "type": "uint256"
            },
            {
                "internalType": "uint256",
                "name": "commissionPaid",
                "type": "uint256"
            }
        ],
        "stateMutability": "view",
        "type": "function"
    }
];

// Initialize DynamoDB
const AWS_REGION = process.env.AWS_REGION || process.env.AWS_DEFAULT_REGION || 'us-east-2';
console.log('Using AWS Region:', AWS_REGION);

const dynamodb = DynamoDBDocument.from(new DynamoDB({
  region: AWS_REGION
}));

// Initialize Web3 with HTTP provider for querying past events
console.log('Using Web3 provider URL:', process.env.WEB3_PROVIDER_URL);
const web3 = new Web3(new Web3.providers.HttpProvider(process.env.WEB3_PROVIDER_URL));
const contract = new web3.eth.Contract(contractABI, process.env.CONTRACT_ADDRESS);

console.log('Contract address:', process.env.CONTRACT_ADDRESS);
// Log detailed event information
const eventDefinitions = contract.options.jsonInterface.filter(x => x.type === 'event');
console.log('Event definitions:', JSON.stringify(eventDefinitions, null, 2));
console.log('Available event names:', eventDefinitions.map(x => x.name));
console.log('Event signatures:', eventDefinitions.map(x => web3.eth.abi.encodeEventSignature(x)));

const BLOCK_CHUNK_SIZE = 200;
const METADATA_TABLE = process.env.METADATA_TABLE_NAME;
const DONOR_TABLE = process.env.DYNAMODB_TABLE_NAME;
const RETRY_DELAY = 500;
const MAX_RETRIES = 3;
const PARALLEL_BATCH_SIZE = 5;

// Helper function to delay execution
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// Helper function to retry failed requests
async function withRetry(fn, retries = MAX_RETRIES) {
  for (let i = 0; i < retries; i++) {
    try {
      return await fn();
    } catch (error) {
      if (error.message.includes('exceeded its compute units') && i < retries - 1) {
        console.log(`Rate limited, attempt ${i + 1}/${retries}. Waiting ${RETRY_DELAY}ms...`);
        await sleep(RETRY_DELAY);
        continue;
      }
      throw error;
    }
  }
}

async function getLastProcessedBlock() {
  try {
    console.log('Getting last processed block from table:', METADATA_TABLE);
    const result = await dynamodb.get({
      TableName: METADATA_TABLE,
      Key: { id: 'last_processed_block' }
    });
    
    console.log('DynamoDB get result:', JSON.stringify(result, null, 2));
    
    if (result.Item) {
      console.log('Found last processed block:', result.Item.last_processed_block);
      return parseInt(result.Item.last_processed_block);
    }
    
    console.log('No last processed block found, checking for existing data...');
    // If no last processed block is found, check if there's any existing data
    const donorScan = await dynamodb.scan({
      TableName: DONOR_TABLE,
      Limit: 1
    });

    console.log('Donor table scan result:', JSON.stringify(donorScan, null, 2));

    if (donorScan.Items && donorScan.Items.length > 0) {
      // If we have existing data but no last processed block,
      // we should start from the current block to avoid reprocessing
      const currentBlock = await withRetry(() => web3.eth.getBlockNumber());
      console.log('Found existing data but no last block. Starting from current block:', currentBlock);
      await updateLastProcessedBlock(currentBlock);
      return currentBlock;
    }

    // If no data exists, start from block 0
    console.log('No existing data found. Starting from block 0');
    return 0;
  } catch (error) {
    console.error('Error getting last processed block:', error);
    console.error('Error details:', JSON.stringify(error, null, 2));
    // In case of error, safely start from block 0
    console.log('Using fallback starting block: 0');
    return 0;
  }
}

async function updateLastProcessedBlock(blockNumber) {
  try {
    await dynamodb.put({
      TableName: METADATA_TABLE,
      Item: {
        id: 'last_processed_block',
        blockNumber: blockNumber.toString()
      }
    });
  } catch (error) {
    console.error('Error updating last processed block:', error);
  }
}

// Add function to verify event existence
async function verifyEvents(fromBlock, toBlock) {
  console.log('\nVerifying events...');
  // Try getting any kind of event to verify connection
  const allEvents = await contract.getPastEvents('allEvents', { fromBlock, toBlock });
  console.log(`Total events found in range: ${allEvents.length}`);
  if (allEvents.length > 0) {
    console.log('First event details:', JSON.stringify(allEvents[0], null, 2));
    console.log('Event types found:', [...new Set(allEvents.map(e => e.event))]);
    console.log('Event signatures found:', [...new Set(allEvents.map(e => e.raw.topics[0]))]);
  }
  return allEvents;
}

async function processEvents(fromBlock, toBlock) {
  try {
    console.log(`\nFetching events from block ${fromBlock} to ${toBlock}...`);
    
    // First verify we can get any events
    await verifyEvents(fromBlock, toBlock);
    
    // Get all relevant events with retry logic
    const [donationEvents, referrerEvents] = await Promise.all([
      withRetry(() => contract.getPastEvents('DonationMade', { fromBlock, toBlock })),
      withRetry(() => contract.getPastEvents('ReferrerActivated', { fromBlock, toBlock }))
    ]);

    console.log(`Found ${donationEvents.length} donation events and ${referrerEvents.length} referrer events`);

    // Process donation events in parallel batches
    for (let i = 0; i < donationEvents.length; i += PARALLEL_BATCH_SIZE) {
      const batch = donationEvents.slice(i, i + PARALLEL_BATCH_SIZE);
      console.log(`Processing donation batch ${i / PARALLEL_BATCH_SIZE + 1} of ${Math.ceil(donationEvents.length / PARALLEL_BATCH_SIZE)}`);
      
      await Promise.all(batch.map(async (event) => {
        const { user, amount, duration } = event.returnValues;
        console.log(`Processing donation from ${user}, amount: ${amount}, duration: ${duration}`);
        
        try {
          const [userDetails, referrerData, userData] = await Promise.all([
            withRetry(() => contract.methods.getUserDetails(user).call()),
            withRetry(() => contract.methods.referrers(user).call()),
            withRetry(() => contract.methods.users(user).call())
          ]);
          
          console.log('User details from contract:', userDetails);
          console.log('Referrer data from contract:', referrerData);
          console.log('User data from contract:', userData);

          const item = {
            address: user.toLowerCase(),
            sponsor: userData.sponsor.toLowerCase(),
            donation: parseInt(amount) / 10**18,
            duration: parseInt(duration),
            isReferrer: referrerData.isActive,
            totalWithdrawn: parseInt(userDetails[5]) / 10**18,  // totalWithdrawn is the 6th return value
            commissionsEarned: parseInt(referrerData.commissionEarned) / 10**18,
            startTime: parseInt(userDetails[2]) * 1000  // startTime is the 3rd return value
          };
          
          console.log('Storing DynamoDB item:', item);

          await dynamodb.put({
            TableName: DONOR_TABLE,
            Item: item
          });
          console.log('Successfully stored donor data for address:', user.toLowerCase());
        } catch (error) {
          console.error(`Error processing donation event for donor ${user}:`, error);
          throw error;
        }
      }));
    }

    // Process referrer events in parallel batches
    for (let i = 0; i < referrerEvents.length; i += PARALLEL_BATCH_SIZE) {
      const batch = referrerEvents.slice(i, i + PARALLEL_BATCH_SIZE);
      console.log(`Processing referrer batch ${i / PARALLEL_BATCH_SIZE + 1} of ${Math.ceil(referrerEvents.length / PARALLEL_BATCH_SIZE)}`);
      
      await Promise.all(batch.map(async (event) => {
        const { referrer } = event.returnValues;
        console.log(`Processing referrer activation for ${referrer}`);
        
        try {
          const referrerData = await withRetry(() => contract.methods.referrers(referrer).call());
          console.log('Referrer data from contract:', referrerData);
          
          await dynamodb.update({
            TableName: DONOR_TABLE,
            Key: { address: referrer.toLowerCase() },
            UpdateExpression: 'SET isReferrer = :isReferrer',
            ExpressionAttributeValues: {
              ':isReferrer': true
            }
          });
          console.log('Successfully updated referrer status for:', referrer.toLowerCase());
        } catch (error) {
          console.error(`Error processing referrer event for ${referrer}:`, error);
          throw error;
        }
      }));
    }

    return donationEvents.length + referrerEvents.length;
  } catch (error) {
    console.error('Error processing events:', error);
    throw error;
  }
}

exports.handler = async (event) => {
  try {
    console.log('Starting Lambda execution...');
    
    // Test Web3 connection with retry
    const blockNumber = await withRetry(() => web3.eth.getBlockNumber());
    console.log('Successfully connected to Web3. Current block:', blockNumber);

    const currentBlock = await withRetry(() => web3.eth.getBlockNumber());
    const lastProcessedBlock = await getLastProcessedBlock();
    
    // For initial testing, only process last 5000 blocks if starting from 0
    const effectiveStartBlock = lastProcessedBlock === 0 ? Math.max(currentBlock - 5000, 0) : lastProcessedBlock + 1;
    console.log(`Using effective start block: ${effectiveStartBlock} (last processed: ${lastProcessedBlock})`);
    
    let processedEvents = 0;

    // Process events in chunks with delay between chunks
    for (let fromBlock = effectiveStartBlock; fromBlock <= currentBlock; fromBlock += BLOCK_CHUNK_SIZE) {
      const toBlock = Math.min(fromBlock + BLOCK_CHUNK_SIZE - 1, currentBlock);
      console.log(`Processing blocks ${fromBlock} to ${toBlock}`);
      const eventsProcessed = await processEvents(fromBlock, toBlock);
      processedEvents += eventsProcessed;
      await updateLastProcessedBlock(toBlock);
      
      // Add delay between chunks to avoid rate limiting
      if (fromBlock + BLOCK_CHUNK_SIZE <= currentBlock) {
        console.log('Waiting between chunks to avoid rate limiting...');
        await sleep(RETRY_DELAY);
      }
    }

    return {
      statusCode: 200,
      body: JSON.stringify({
        message: 'Successfully processed events',
        processedEvents,
        fromBlock: lastProcessedBlock + 1,
        toBlock: currentBlock
      })
    };
  } catch (error) {
    console.error('Error in lambda handler:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({
        message: 'Error processing events',
        error: error.message
      })
    };
  } finally {
    // Close the WebSocket connection
    web3.currentProvider.disconnect();
  }
}; 